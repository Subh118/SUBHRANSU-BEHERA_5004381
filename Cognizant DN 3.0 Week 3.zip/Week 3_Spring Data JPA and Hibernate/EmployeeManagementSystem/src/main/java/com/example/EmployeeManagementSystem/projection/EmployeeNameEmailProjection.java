package com.example.EmployeeManagementSystem.projection;

import com.example.EmployeeManagementSystem.entity.Department;

public interface EmployeeNameEmailProjection {
    String getName();
    String getEmail();
    Department getDepartment();
}
