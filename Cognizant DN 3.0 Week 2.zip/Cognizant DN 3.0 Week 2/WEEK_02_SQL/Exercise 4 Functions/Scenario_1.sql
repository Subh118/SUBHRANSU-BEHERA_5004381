CREATE OR REPLACE FUNCTION CalculateAge ( 
    p_DOB DATE 
) RETURN NUMBER IS 
    v_Age NUMBER; 
BEGIN 
    -- Calculate age 
    v_Age := FLOOR((SYSDATE - p_DOB) / 365.25); 
    RETURN v_Age; 
END; 
/ 