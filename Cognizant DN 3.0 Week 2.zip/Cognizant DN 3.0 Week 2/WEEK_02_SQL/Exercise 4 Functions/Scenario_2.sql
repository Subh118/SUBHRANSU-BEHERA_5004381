CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment ( 
    p_LoanAmount NUMBER, 
    p_InterestRate NUMBER, 
    p_LoanDurationYears NUMBER 
) RETURN NUMBER IS 
    v_MonthlyRate NUMBER; 
    v_NumberOfPayments NUMBER; 
    v_MonthlyInstallment NUMBER; 
BEGIN 
    -- Convert annual interest rate to monthly and loan duration to number of months 
    v_MonthlyRate := p_InterestRate / 12 / 100; 
    v_NumberOfPayments := p_LoanDurationYears * 12; 
     
    -- Calculate monthly installment using the formula for an annuity 
    v_MonthlyInstallment := p_LoanAmount * v_MonthlyRate / (1 - POWER(1 + 
v_MonthlyRate, -v_NumberOfPayments)); 
     
    RETURN v_MonthlyInstallment; 
END; 
/ 