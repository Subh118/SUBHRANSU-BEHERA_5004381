DECLARE 
    CURSOR customer_cursor IS 
        SELECT CustomerID, DOB FROM Customers; 
     
    v_CustomerID Customers.CustomerID%TYPE; 
    v_DOB Customers.DOB%TYPE; 
    v_Age NUMBER; 
BEGIN 
    FOR customer_record IN customer_cursor LOOP 
        v_CustomerID := customer_record.CustomerID; 
        v_DOB := customer_record.DOB; 
         
        -- Calculate age 
        v_Age := FLOOR((SYSDATE - v_DOB) / 365.25); 
         
        IF v_Age > 60 THEN 
            -- Apply 1% discount to loan interest rates 
            UPDATE Loans 
            SET InterestRate = InterestRate * 0.99 
            WHERE CustomerID = v_CustomerID; 
        END IF; 
    END LOOP; 
     
    COMMIT; 
END; 