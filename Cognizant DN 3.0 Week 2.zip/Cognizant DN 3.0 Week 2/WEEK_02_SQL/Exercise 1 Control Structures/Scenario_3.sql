DECLARE 
    CURSOR loan_cursor IS 
        SELECT LoanID, CustomerID, EndDate FROM Loans 
        WHERE EndDate BETWEEN SYSDATE AND SYSDATE + 30; 
     
    v_LoanID Loans.LoanID%TYPE; 
    v_CustomerID Loans.CustomerID%TYPE; 
    v_EndDate Loans.EndDate%TYPE; 
    v_CustomerName Customers.Name%TYPE; 
BEGIN 
    FOR loan_record IN loan_cursor LOOP 
        v_LoanID := loan_record.LoanID; 
        v_CustomerID := loan_record.CustomerID; 
        v_EndDate := loan_record.EndDate; 
         
        -- Fetch customer's name 
        SELECT Name INTO v_CustomerName 
        FROM Customers 
        WHERE CustomerID = v_CustomerID; 
         
        -- Print reminder message 
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ' || v_CustomerName ||  
                             ' (CustomerID: ' || v_CustomerID ||  
                             ') has a loan (LoanID: ' || v_LoanID ||  
                             ') due on ' || TO_CHAR(v_EndDate, 'DD-MON-YYYY') || '.'); 
    END LOOP; 
END; 